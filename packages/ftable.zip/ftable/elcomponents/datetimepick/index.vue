<template>
	<el-date-picker class="eldebugg"></el-date-picker>
</template>

<script>
import { defineComponent } from "vue";

export default defineComponent({});
</script>

<style>
/* .eldebugg .el-input__prefix {
	transform: translateY(8px) !important;
}
.eldebugg .el-input__suffix {
	transform: translateY(8px) !important;
} */
</style>
