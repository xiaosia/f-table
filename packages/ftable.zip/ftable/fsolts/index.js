
import { defineComponent, h } from "vue";

export default defineComponent({
    name: 'f-solts',
    render(){
        return h("div", "solts")
    }
})