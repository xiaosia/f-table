<!--
 * @Description: 输入框
 * @Autor: Seven
 * @Date: 2022-02-09 11:19:17
 * @LastEditors: Seven
 * @LastEditTime: 2022-02-10 10:10:34
-->
<template>
    <el-input></el-input>
</template>

<script>
import { defineComponent } from "vue";

export default defineComponent({
    setup(){
        
    }
})
</script>
